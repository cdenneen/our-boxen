# Parallels 9 Puppet Module for Boxen

Installs Parallels 9. This doesn't include the Parralels license

## Usage

```puppet
include parallels
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.

## TODO:
* Make it more general for all versions of parallels
