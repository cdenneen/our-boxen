# Cyberduck
[Cyberduck](http://cyberduck.ch/) FTP, SFTP, WebDAV & cloud
storage browser for Mac & Windows.

## Usage

```puppet
include cyberduck
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
