# Puppet Module that installs Firefox for Boxen

This module installs Firefox

## Usage

```puppet
include firefox
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script` directory for other useful tools.
