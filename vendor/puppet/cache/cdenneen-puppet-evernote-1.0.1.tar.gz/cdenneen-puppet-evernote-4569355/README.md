# Evernote Puppet Module for Boxen

Install [Evernote](http://www.evernote.com), and remember everything!

## Usage

```puppet
include evernote
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
