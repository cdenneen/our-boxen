# Lync Puppet Module for Boxen

Install [Microsoft Lync](http://www.microsoft.com/mac/enterprise/lync), an enterprise-ready unified communications platform.

## Usage

```puppet
include lync
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
